package game;

public class Application {

	public static void main(String[] args) {
		Game game = new Game();
		Level level1 = new Level1(game);
		game.setLevel(level1);
		game.play();
		game.play();
		game.play();
		game.play();
		game.play();
		game.play();
		game.play();
		game.play();
		game.play();
		game.play();
	}

}
