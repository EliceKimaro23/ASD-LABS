package game;

import java.util.Random;

public class Game {
	private int totalPoints = 0;
	private Level level;

	public void play() {
		Random random = new Random();
		level.addPoints(random.nextInt(7));
		System.out.println("points="+totalPoints+" level="+level.getLevel());
	}

	public int getTotalPoints() {
		return totalPoints;
	}

	public void setLevel(Level level) {
		this.level = level;
	}

	public void addPoints(int newPoints) {
		totalPoints = totalPoints + newPoints;
	}

}
