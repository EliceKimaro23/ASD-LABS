package game;

abstract public class Level {
    Game game;
    public Level(Game game) {
        this.game = game;
    }
    abstract public void addPoints(int newPoints);
    abstract public String getLevel();
}
