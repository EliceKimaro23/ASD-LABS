package game;

public class Level1 extends Level{

    public Level1(Game game) {
        super(game);
    }

    @Override
    public void addPoints(int newPoints) {
        game.addPoints(newPoints);
        if (game.getTotalPoints() > 10){
            Level level2 = new Level2(game);
            game.setLevel(level2);
            game.addPoints(1);
        }
    }

    @Override
    public String getLevel() {
        return "Level 1";
    }
}
