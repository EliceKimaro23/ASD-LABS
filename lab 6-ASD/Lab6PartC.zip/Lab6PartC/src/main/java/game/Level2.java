package game;

public class Level2 extends Level{

    public Level2(Game game) {
        super(game);
    }

    @Override
    public void addPoints(int newPoints) {
        game.addPoints(2 * newPoints);
        if (game.getTotalPoints() >= 15){
            Level level2_5 = new Level2_5(game);
            game.setLevel(level2_5);
            game.addPoints(1);
        }
    }

    @Override
    public String getLevel() {
        return "Level 2";
    }
}
