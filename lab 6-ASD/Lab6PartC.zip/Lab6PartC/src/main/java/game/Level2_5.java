package game;

public class Level2_5 extends Level {

    public Level2_5(Game game) {
        super(game);
    }

    @Override
    public void addPoints(int newPoints) {
        game.addPoints(newPoints);
        if (game.getTotalPoints() > 20){
            Level level2 = new Level3(game);
            game.setLevel(level2);
            game.addPoints(2);
        }
    }

    @Override
    public String getLevel() {
        return "Level 2_5";
    }
}
