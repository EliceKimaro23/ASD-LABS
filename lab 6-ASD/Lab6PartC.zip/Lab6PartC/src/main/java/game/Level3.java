package game;

public class Level3 extends Level{

    public Level3(Game game) {
        super(game);
    }

    @Override
    public void addPoints(int newPoints) {
        game.addPoints(3 * newPoints);
    }

    @Override
    public String getLevel() {
        return "Level 3";
    }
}
