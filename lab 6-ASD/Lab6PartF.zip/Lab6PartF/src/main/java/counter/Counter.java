package counter;

import counter.state.State;

public class Counter extends Subject{
	
	private int count=0;
	private State state;
	
	public void increment(){
		state.increment();
	}
	
	public void decrement(){
		state.decrement();
	}

	public void setNewCounterValue(int newValue) {
		count = newValue;
		notify(count);
	}

	public int getCount() {
		return count;
	}

	public void setState(State state) {
		this.state = state;
	}
}
