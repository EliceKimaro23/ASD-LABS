package counter;

public interface IObserver {
    void notify(int count);
}
