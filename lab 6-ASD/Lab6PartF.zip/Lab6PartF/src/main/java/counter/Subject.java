package counter;

import java.util.ArrayList;
import java.util.List;

public abstract class Subject {
    private List<IObserver> observers = new ArrayList<>();

    public void notify(int count){
        for (IObserver o: observers){
            o.notify(count);
        }
    }

    public void addObserver(IObserver observer){
        observers.add(observer);
    }

    public void removeObserver(IObserver observer){
        for (IObserver o: observers){
            if (o == observer){
                observers.remove(observer);
                break;
            }
        }
    }
}
