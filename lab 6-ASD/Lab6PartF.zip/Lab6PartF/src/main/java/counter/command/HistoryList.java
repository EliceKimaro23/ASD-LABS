package counter.command;

import java.util.ArrayList;
import java.util.List;

public class HistoryList {
    private final List<Command> commands, undoCommand;

    public HistoryList(){
        commands = new ArrayList<>();
        undoCommand = new ArrayList<>();
    }

    public void addCommand(Command command){
        commands.add(command);
    }

    public void undo(){
        if (commands.size() > 0){
            Command lastCommand = commands.get(commands.size() - 1);
            commands.remove(lastCommand);
            lastCommand.unExecute();
            undoCommand.add(lastCommand);
        }
    }

    public void redo(){
        if (undoCommand.size() > 0){
            Command lastUndoCommand = undoCommand.get(undoCommand.size() - 1);
            undoCommand.remove(lastUndoCommand);
            lastUndoCommand.execute();
            commands.add(lastUndoCommand);
        }
    }
}
