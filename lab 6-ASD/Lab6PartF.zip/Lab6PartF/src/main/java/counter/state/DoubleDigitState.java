package counter.state;

import counter.Counter;

public class DoubleDigitState extends State{

    public DoubleDigitState(Counter counter) {
        super(counter);
    }

    @Override
    public void increment() {
        counter.setNewCounterValue(counter.getCount() + 2);
        if ((counter.getCount() / 100) != 0)
            counter.setState(new ThreeDigitState(counter));
    }

    @Override
    public void decrement() {
        counter.setNewCounterValue(counter.getCount() - 2);
        if ((counter.getCount() / 10) != 0)
            counter.setState(new SingleDigitState(counter));
    }
}
