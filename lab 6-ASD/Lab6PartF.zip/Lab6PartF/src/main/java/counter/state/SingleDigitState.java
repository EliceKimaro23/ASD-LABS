package counter.state;

import counter.Counter;

public class SingleDigitState extends State{

    public SingleDigitState(Counter counter) {
        super(counter);
    }

    @Override
    public void increment() {
        counter.setNewCounterValue(counter.getCount() + 1);
        if ((counter.getCount() / 10) != 0)
            counter.setState(new DoubleDigitState(counter));
    }

    @Override
    public void decrement() {
        if (counter.getCount() > 0)
            counter.setNewCounterValue(counter.getCount() - 1);
    }
}
