package counter.state;

import counter.Counter;

public abstract class State {
    Counter counter;
    public State(Counter counter) {
        this.counter = counter;
    }
    public abstract void increment();
    public abstract void decrement();
}
