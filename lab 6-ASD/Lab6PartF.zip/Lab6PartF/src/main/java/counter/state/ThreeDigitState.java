package counter.state;

import counter.Counter;

public class ThreeDigitState extends State{

    public ThreeDigitState(Counter counter) {
        super(counter);
    }

    @Override
    public void increment() {
        counter.setNewCounterValue(counter.getCount() + 3);
    }

    @Override
    public void decrement() {
        counter.setNewCounterValue(counter.getCount() - 3);
        if ((counter.getCount() / 100) != 0)
            counter.setState(new DoubleDigitState(counter));
    }
}
